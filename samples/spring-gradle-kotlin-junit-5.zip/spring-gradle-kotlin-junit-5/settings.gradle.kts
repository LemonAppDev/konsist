rootProject.name = "spring-gradle-kotlin-junit-5"

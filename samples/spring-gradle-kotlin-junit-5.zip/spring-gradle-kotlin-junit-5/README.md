# Konsist Sample

This a konsist sample is configured using Spring Gradle Kotlin, and Junit 5. Other samples are located [here](..). 

The [SampleKonsistTest.kt](src/konsistTest/kotlin/com/sample/SampleKonsistTest.kt) class is placed in `konsistTest` 
test directory defined by the
[JVM Test Suite Plugin](https://docs.gradle.org/current/userguide/jvm_test_suite_plugin.html).

To run test use IDE UI or run `./gradlew konsistTest` command.


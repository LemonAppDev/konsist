package com.lemonappdev.konsist.externalfixture

interface FixtureExternalGenericInterface<T>

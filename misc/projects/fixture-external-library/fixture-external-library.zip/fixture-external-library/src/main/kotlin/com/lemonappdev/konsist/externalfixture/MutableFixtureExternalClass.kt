package com.lemonappdev.konsist.externalfixture

open class MutableFixtureExternalClass

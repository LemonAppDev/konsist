package com.lemonappdev.konsist.externalfixture

open class FixtureExternalGenericClass<T>()

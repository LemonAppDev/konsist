package com.lemonappdev.konsist.externalfixture

open class FixtureExternalGenericClassWithParameter<T>(val param: String)

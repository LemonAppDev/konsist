package com.lemonappdev.konsist.externalfixture

open class FixtureExternalClassWithParameter(val param: String)

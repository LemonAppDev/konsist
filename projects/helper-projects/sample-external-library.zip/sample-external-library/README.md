# Sample External Library

Generated library artifact used to test external parents.

Build artifact `./gradlew build`. Artifact wil appear in `build/libs` directory.



package com.lemonappdev.konsist.externalsample

open class SampleExternalClassWithParameter(val param: String)

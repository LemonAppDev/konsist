package com.lemonappdev.konsist.externalsample

open class MutableSampleExternalClass

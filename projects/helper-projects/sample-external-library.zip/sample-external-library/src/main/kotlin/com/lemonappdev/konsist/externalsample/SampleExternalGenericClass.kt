package com.lemonappdev.konsist.externalsample

open class SampleExternalGenericClass<T>()

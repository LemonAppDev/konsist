package com.lemonappdev.konsist.externalsample

open class SampleExternalGenericClassWithParameter<T>(val param: String)

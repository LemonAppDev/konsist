package com.lemonappdev.konsist.externalsample

interface SampleExternalGenericInterface<T>
